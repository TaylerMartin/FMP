﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public enum ActionState
{
    finished, InProgress, failed
}

public class Actions : MonoBehaviour
{
    [Header("Debug tools")]
    public bool EatDebug = false;
    public bool DrinkDebug = false;
    public bool MoveToDebug = false;
    public bool ClaimBedDebug = false;
    public bool GoToBedDebug = false;
    public bool PickUpDebug = false;
    public bool DropOffDebug = false;
    public Vector3 MoveToLocation = new Vector3(1f, 1f);
    [Header("Eat Food Variables")]
    public float FoodMultiplier;

    [Header("Drink Water Variables")]
    public float WaterMultiplier;

    [Header("MoveTo Variables")]
    public float MoveSpeed = 1f;
    public float MoveCost = 0.1f;

    [Header("Generic Variables")]
    GameObject Destination;

    private Inventory VillagerInventory;
    private Work VillagerWork;

    private void Start()
    {
        VillagerInventory = GetComponent<Inventory>();
        VillagerWork = GetComponent<Work>();
    }

    public ActionState EatFood(Inventory EatFrom, Work Villager, int amount)
    {
        if (EatFrom.InventoryAmount >= amount && EatFrom.InventoryContains == ObjectType.Food)
        {
            Villager.Hunger += amount * FoodMultiplier;
            EatFrom.InventoryAmount -= amount;
            return ActionState.finished;
        }
        else
        {
            return ActionState.failed;
        }

    }

    public ActionState DrinkWater(Inventory EatFrom, Work Villager, int amount)
    {
        if (EatFrom.InventoryAmount >= amount && EatFrom.InventoryContains == ObjectType.Water)
        {
            Villager.Thirst += amount * WaterMultiplier;
            EatFrom.InventoryAmount -= amount;
            return ActionState.finished;
        }
        else
        {
            return ActionState.failed;
        }

    }

    public ActionState MoveTo(Vector3 Location)
    {
        transform.position = Vector3.MoveTowards(transform.position, Location, MoveSpeed);
        if(Location == transform.position)
        {
            return ActionState.finished;
        }
        else
        {
            VillagerWork.Energy -= MoveCost;
            return ActionState.InProgress;
        }
    }

    public ActionState GoToBed()
    {
        if (VillagerInventory.myBed != null)
        {
            return MoveTo(VillagerInventory.myBed.transform.position);
        }
        else
        {
            return ActionState.InProgress;
        }
    }

    public ActionState DropOff()
    {
        GameObject Storehouse = GameObject.FindGameObjectWithTag("Storage");
        Storage storage = Storehouse.GetComponent<Storage>();
        if (storage == null)
        {
            return ActionState.failed;
        }
        Destination = Storehouse;
        if (MoveTo(Destination.transform.position) == ActionState.finished)
        {
            if (storage.ExchangeResources(VillagerInventory))
            {
                Destination = null;
                return ActionState.finished;
            }
            else
            {
                return ActionState.failed;
            }
        }
        else
        {
            return ActionState.InProgress;
        }
    }

    public ActionState PickUp(ObjectType resource, float amount)
    {
        GameObject[] Storehouses = GameObject.FindGameObjectsWithTag("Storage");
        Storage temp;
        foreach (GameObject storehouse in Storehouses)
        {
            temp = storehouse.GetComponent<Storage>();
            if (temp.StorageSlots[resource] >= amount)
            {
                Destination = storehouse;
                break;
            }
        }
        if (Destination == null)
        {
            return ActionState.failed;
        }
        if (MoveTo(Destination.transform.position) == ActionState.finished)
        {
            if (Destination.GetComponent<Storage>().ExchangeResources(VillagerInventory, amount, resource, true))
            {
                Destination = null;
                return ActionState.finished;
            }
            else
            {
                return ActionState.failed;
            }
        }
        else
        {
            return ActionState.InProgress;
        }

    }

    private ActionState Claimhouse()
    {
        Bed temp = GameObject.FindGameObjectWithTag("House").GetComponent<Bed>();
        print(temp.name);
        if (temp.Owner == null)
        {

            ActionState returnval = temp.BecomeOwner(gameObject);
            if (returnval == ActionState.finished)
            {
                VillagerInventory.myBed = temp;
            }
            return returnval;
        }
        else
        {
            return ActionState.failed;
        }
    }

    private void Update()
    {
        Debugs();

    }

    private void Debugs()
    {
        if (EatDebug)
        {
            EatDebug = false;
            EatFood(VillagerInventory, VillagerWork, 1);
        }

        if (DrinkDebug)
        {
            DrinkDebug = false;
            DrinkWater(VillagerInventory, VillagerWork, 1);
        }

        if (MoveToDebug)
        {
            MoveToDebug = !(MoveTo(MoveToLocation) == ActionState.finished);
        }

        if (ClaimBedDebug)
        {
            ClaimBedDebug = !(Claimhouse() == ActionState.finished);
        }

        if (GoToBedDebug)
        {
            GoToBedDebug = !(GoToBed() == ActionState.finished);
        }

        if (PickUpDebug)
        {
            PickUpDebug = !(PickUp(ObjectType.Food, 10) == ActionState.finished);
        }
        if (DropOffDebug)
        {
            DropOffDebug = !(DropOff() == ActionState.finished);
        }
    }
}
