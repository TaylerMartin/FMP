﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Storage : MonoBehaviour
{

    public Dictionary<ObjectType, float> StorageSlots;
    public float FoodDisplay;
    public float WaterDisplay;
    public float StoneDisplay;
    public float WoodDisplay;
    // Use this for initialization
    void Start()
    {
        StorageSlots = new Dictionary<ObjectType, float>();
        StorageSlots.Add(ObjectType.Food, 10);
        StorageSlots.Add(ObjectType.Water, 10);
        StorageSlots.Add(ObjectType.Stone, 10);
        StorageSlots.Add(ObjectType.Wood, 10);
       
    }

    // Update is called once per frame
    void Update()
    {
        WaterDisplay = StorageSlots[ObjectType.Water];
        FoodDisplay = StorageSlots[ObjectType.Food];
        StoneDisplay = StorageSlots[ObjectType.Stone];
        WoodDisplay = StorageSlots[ObjectType.Wood];
    }

    public bool ExchangeResources(Inventory villager)
    {
        return ExchangeResources(villager, villager.InventoryAmount, villager.InventoryContains, false);
    }

    public bool ExchangeResources(Inventory villager, float amount, ObjectType type, bool Pickup)
    {
        if (Pickup)
        {
            if (villager.InventoryContains != type && villager.InventoryContains != ObjectType.Nothing)
            {
                return false;
            }
            if (StorageSlots[type] >= amount)
            {
                if (villager.InventoryContains == ObjectType.Nothing)
                {
                    villager.InventoryContains = type;
                    villager.InventoryAmount = amount;
                }
                else
                {
                    villager.InventoryAmount += amount;
                }

                StorageSlots[type] -= amount;
                return true;
            }
            else
            {
                return false;
            }

        }
        else
        {
            if (villager.InventoryAmount >= amount)
            {
                StorageSlots[type] += amount;
                villager.InventoryAmount -= amount;
                return true;
            }
            else
            {
                return false;
            }
        }
    }
}
