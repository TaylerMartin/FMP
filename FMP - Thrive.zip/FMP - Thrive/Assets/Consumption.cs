﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Consumption : MonoBehaviour
{

    private Work workRef;
    private float HungerTick;
    private float ThirstTick;
    private float EnergyTick;
   
    private float HungerIncrementer;
    private float ThirstIncrementer;
    private float EnergyIncrementer;
    // Use this for initialization
    void Start()
    {
        workRef = GetComponent<Work>();
        HungerTick = 1f;
        ThirstTick = 1f;
        EnergyTick = 10f;
        HungerIncrementer = 1f;
        ThirstIncrementer = 1f;
        EnergyIncrementer = 1f;
        StartCoroutine(GainHunger());
        StartCoroutine(GainThirst());
        StartCoroutine(LoseEnergy());
    }

    // Update is called once per frame
    void Update()
    {

    }

    IEnumerator GainHunger()
    {
        while (true)
        {
            yield return new WaitForSeconds(HungerTick);
            if (!workRef.IsDead)
            {
                workRef.Hunger -= HungerIncrementer/2;
            }
            if (!workRef.IsInBed)
            {
                workRef.Hunger -= HungerIncrementer / 2;
            }

        }
    }
    IEnumerator GainThirst()
    {
        while (true)
        {
            yield return new WaitForSeconds(ThirstTick);
            if (!workRef.IsDead)
            {
                workRef.Thirst -= ThirstIncrementer/2;
            }
            if (!workRef.IsInBed)
            {
                workRef.Thirst -= ThirstIncrementer / 2;
            }
        }

    }

    IEnumerator LoseEnergy()
    {
        while (true)
        {
            yield return new WaitForSeconds(EnergyTick);
            if (!workRef.IsDead && !workRef.IsInBed)
            {
                workRef.Energy -= EnergyIncrementer;
            }
        }
    }
}
