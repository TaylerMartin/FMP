﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Actions : MonoBehaviour
{
    [Header("Debug tools")]
    public bool EatDebug = false;
    public bool DrinkDebug = false;
    public bool MoveToDebug = false;
    public bool ClaimBedDebug = false;
    public bool GoToBedDebug = false;

    public Vector3 MoveToLocation = new Vector3(1f, 1f);
    [Header("Eat Food Variables")]
    public float FoodMultiplier;

    [Header("Drink Water Variables")]
    public float WaterMultiplier;

    [Header("MoveTo Variables")]
    public float MoveSpeed = 1f;
    public float MoveCost = 0.1f;

    private Inventory VillagerInventory;
    private Work VillagerWork;

    private void Start()
    {
        VillagerInventory = GetComponent<Inventory>();
        VillagerWork = GetComponent<Work>();
    }

    public bool EatFood(Inventory EatFrom, Work Villager, int amount)
    {
        if (EatFrom.InventoryAmount >= amount && EatFrom.InventoryContains == ObjectType.Food)
        {
            Villager.Hunger += amount * FoodMultiplier;
            EatFrom.InventoryAmount -= amount;
            return true;
        }
        else
        {
            return false;
        }

    }

    public bool DrinkWater(Inventory EatFrom, Work Villager, int amount)
    {
        if (EatFrom.InventoryAmount >= amount && EatFrom.InventoryContains == ObjectType.Water)
        {
            Villager.Thirst += amount * WaterMultiplier;
            EatFrom.InventoryAmount -= amount;
            return true;
        }
        else
        {
            return false;
        }

    }

    public bool MoveTo(Vector3 Location)
    {
        transform.position = Vector3.MoveTowards(transform.position, Location, MoveSpeed);
        VillagerWork.Energy -= MoveCost;
        return Location == transform.position;
    }

    public bool GoToBed()
    {
        if (VillagerInventory.myBed != null)
        {
            return MoveTo(VillagerInventory.myBed.transform.position);
        }
        else
        {
            return false;
        }
    }

    private bool Claimhouse()
    {
        Bed temp = GameObject.FindGameObjectWithTag("House").GetComponent<Bed>();
        print(temp.name);
        if (temp.Owner == null)
        {
            
            bool returnval = temp.BecomeOwner(gameObject);
            if (returnval)
            {
                VillagerInventory.myBed = temp;
            }
            return returnval;
        }
        else
        {
            return false;
        }
    }

    private void Update()
    {
        Debugs();

    }

    private void Debugs()
    {
        if (EatDebug)
        {
            EatDebug = false;
            EatFood(VillagerInventory, VillagerWork, 1);
        }

        if (DrinkDebug)
        {
            DrinkDebug = false;
            DrinkWater(VillagerInventory, VillagerWork, 1);
        }

        if (MoveToDebug)
        {
            MoveToDebug = !MoveTo(MoveToLocation);
        }

        if (ClaimBedDebug)
        {
            ClaimBedDebug = !Claimhouse();
        }

        if (GoToBedDebug)
        {
            GoToBedDebug = !GoToBed();
        }
    }
}
