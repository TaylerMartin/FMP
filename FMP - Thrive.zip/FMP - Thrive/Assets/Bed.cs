﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEditor;
public class Bed : MonoBehaviour
{

    [Header("Properties")]
    public GameObject Owner;
    private Work workRef;
    private Actions ActionsRef;
    public float BedQuality;
    public float BedTick;

    [Header("Debug Tools")]
    public bool DebugOne = false;
    public bool DebugTwo = false;

    void Start()
    {
    }

    public bool BecomeOwner(GameObject newOwner)
    {
        if (newOwner.tag.Contains("Villager"))
        {
            Owner = newOwner;
            workRef = newOwner.GetComponent<Work>();
            ActionsRef = newOwner.GetComponent<Actions>();
            StartCoroutine(Sleep());
            return true;
        }
        else
        {
            return false;
        }
    }

    void Update()
    {
        if (Owner != null)
        {
            workRef.IsInBed = (Vector3.Distance(transform.position,Owner.transform.position) <= 0.1f);
        }
    }


    IEnumerator Sleep()
    {
        while (true)
        {
            yield return new WaitForSeconds(BedTick);
            if (!workRef.IsDead && workRef.IsInBed)
            {
                workRef.Energy += BedQuality;
            }
        }
    }

}
